package phase1project;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
public class javaproject
{
	   public void maincontent() {
		int option='\0';
		Scanner sc=new Scanner(System.in);
		System.out.println("WELCOME TO THE JAVA PROJECT ");
		System.out.println(" MADE BY NIDHI");
		do
		{
			System.out.println("\n1. Displaying current files names in ascending order");
			System.out.println("2. Details of the user interface");
			System.out.println("3. Exit the application");
			System.out.println("Enter your option in main menu");
			option =sc.nextInt();
			switch(option)
			{
			case 1:
				displayfiles obj=new displayfiles();
				obj.display();
				break;
			case 2:
				int opt;
		         do
				{
					System.out.println("1. Add the file to the existing directory list");
					System.out.println("2. Delete a user specified file from the existing directory list");
					System.out.println("3. Search a user specified file from the main directory");
					System.out.println("4. Navigate back to the main context");
					opt=sc.nextInt();
					switch(opt)
					{
					case 1:
						try { 
							 File myfile=new File("D:\\nidhi.txt");
							 if(myfile.createNewFile()) {
								 System.out.println("File created: "+myfile.getName());
							 }
							 else
							 {
								 System.out.println("File Already exists");
							 }
						}
							 catch(IOException e) {
								 System.out.println("An error occurred");
								 e.printStackTrace();
							 }
	
							 break; 
		
					case 2:
						try {
							Files.deleteIfExists(Paths.get("D:\\nidhi.txt"));
						}
						 catch(IOException e) {
							 System.out.println("An error occurred");
						 }
						System.out.println("Deletion Successful");
						break;
					case 3:
					{
						File myfile=new File("D:\\");
						String[] flist= myfile.list();
						int flag=0;
						if(flist==null) {
							System.out.println("Empty directory");
						}
						else {
							for(int i=0;i<flist.length;i++) {
								String nidhi=flist[i];
								if(nidhi.equals("nidhi.txt")) {
									System.out.println(nidhi + "\tfound");
									flag=1;
								}
							}
						}
						if (flag==0) {
							System.out.println("File not Found");
						}
					}
					break;
					case 4:
						javaproject object=new javaproject();
						object.maincontent();
						object.maincontent();
						break;
						default:
							System.out.println("Invalid choice");
							break;
					}
					}
						while(opt!=4);
							break;
			case 3:
				break;
			default:
					System.out.println("Invalid option");
			}
		}
		while(option!=3);
		System.out.println("Thanks for using my application");
   }
}

					
				
