package phase1project;

public class mainclass {

	public static void main(String[] args) {
		javaproject object=new javaproject();
		object.maincontent();

	}

}
