package phase1project;

import java.io.File;

public class displayfiles {
	public void display()
	{
		File file=new File("D:\\");
		String[] files=file.list();
		for(String string :files)
			System.out.println(string);
	}


}
